import gradio as gr
from tryon.image_tryon import run_image_tryon
from tryon.video_tryon import run_video_tryon

def image_ui(p, c):
    return run_image_tryon(p, c)

def video_ui(v, c):
    return run_video_tryon(v, c)

gr.TabbedInterface(
    [
        gr.Interface(image_ui, ["image", "image"], "image", title="Image Try-On"),
        gr.Interface(video_ui, ["video", "image"], "video", title="Video Try-On")
    ],
    ["Image", "Video"]
).launch()