# Compliant Virtual Try-On System (Image + Video)

✔ Clothing replacement only  
✔ No nudification, no sexual content  
✔ Research & commercial safe  

## Features
- Stable Diffusion 1.5
- ControlNet (pose, segmentation)
- VITON-HD / IDM-VTON hooks
- Image & video try-on
- Auto GPU / CPU detection
- Gradio UI
- Docker support