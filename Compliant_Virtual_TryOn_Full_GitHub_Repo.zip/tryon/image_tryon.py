def run_image_tryon(person, cloth):
    return person