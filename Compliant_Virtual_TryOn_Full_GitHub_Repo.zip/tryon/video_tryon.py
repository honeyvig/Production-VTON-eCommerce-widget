def run_video_tryon(video, cloth):
    return video