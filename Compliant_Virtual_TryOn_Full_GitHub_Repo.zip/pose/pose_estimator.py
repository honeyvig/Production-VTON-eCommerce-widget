def extract_pose(image):
    # Placeholder for OpenPose / DWpose
    return None