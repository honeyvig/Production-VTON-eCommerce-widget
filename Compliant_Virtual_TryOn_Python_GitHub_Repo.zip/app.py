import gradio as gr
from tryon import virtual_tryon

def run(person, cloth):
    return virtual_tryon(person, cloth)

gr.Interface(run, ["image", "image"], "image").launch()