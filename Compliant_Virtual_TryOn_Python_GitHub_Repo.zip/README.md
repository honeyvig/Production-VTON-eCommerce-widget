# Compliant Virtual Try-On (Clothing Replacement Only)

Legal, ethical virtual try-on pipeline.
No nudification, no sexual content, no body modification.

Stack:
- Stable Diffusion (safe configs)
- ControlNet (pose, segmentation)
- SAM / SCHP
- Gradio UI