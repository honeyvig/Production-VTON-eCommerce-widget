def virtual_tryon(person_img, cloth_img):
    return person_img