def segment_person(image):
    return image