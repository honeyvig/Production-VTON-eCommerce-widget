def extract_pose(image):
    return None